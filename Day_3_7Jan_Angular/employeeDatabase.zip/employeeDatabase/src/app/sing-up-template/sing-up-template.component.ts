import { Component, OnInit } from '@angular/core';
import { User } from './singup.interface';

@Component({
	selector: 'app-sing-up-template',
	templateUrl: 'sing-up-template.component.html',
	styleUrls: ['./sing-up-template.component.css']
})
export class SingUpTemplateComponent implements OnInit {

	user: User = {
		name: 'Todd',
		account: {
			email: '',
			confirm: ''
		}
	};

	onSubmit({ value, valid }: { value: User, valid: boolean }) {
		console.log(value, valid);
	}
	constructor() { }

	ngOnInit() {
	}

}
