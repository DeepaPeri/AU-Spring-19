import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingUpTemplateComponent } from './sing-up-template.component';

describe('SingUpTemplateComponent', () => {
  let component: SingUpTemplateComponent;
  let fixture: ComponentFixture<SingUpTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingUpTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingUpTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
