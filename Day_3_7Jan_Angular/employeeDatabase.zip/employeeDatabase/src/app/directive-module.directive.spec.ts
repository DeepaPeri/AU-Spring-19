import { DirectiveModuleDirective } from './directive-module.directive';

describe('DirectiveModuleDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectiveModuleDirective(9,5);
    expect(directive).toBeTruthy();
  });
});
