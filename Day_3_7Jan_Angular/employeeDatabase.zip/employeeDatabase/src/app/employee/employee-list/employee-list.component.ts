import { Component, OnInit, Input } from '@angular/core';
import { TestServiceService } from 'src/app/test-service.service';
import {ViewChild, ElementRef} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import { filter } from 'rxjs/operators'

@Component({
	selector: 'app-employee-list',
	templateUrl: './employee-list.component.html',
	styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
	@ViewChild('searchText') searchTextRef: ElementRef;
	users: any;
	empId : any;
	loading: any;
	constructor(private testService: TestServiceService,private route: ActivatedRoute ) {
		this.route.params.subscribe( params => {
			console.log(params);
			this.empId = params.id;
			this.loading = true;
		});		
	}

	ngOnInit() {
		this.testService.getUsers().subscribe(data => {
			console.log("Received users: " );
			console.log(data.result);
			if(this.empId){
				this.users = data.result.filter((user, index, array) => {
					return user.id == this.empId;
				});
			}else{
				this.users = data.result;
			}
			console.log(this.users);
		});
	}
}
