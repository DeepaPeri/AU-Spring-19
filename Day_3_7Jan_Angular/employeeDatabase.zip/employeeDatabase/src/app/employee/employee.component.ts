import { Component, OnInit } from '@angular/core';
import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Component({
	selector: 'app-employee',
	templateUrl: './employee.component.html',
	styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
	@Input()
  	public emp: any;
	public title: string;

	constructor() {
		this.title = "Hello";
	}
	
	ngOnInit() {
	}
}
