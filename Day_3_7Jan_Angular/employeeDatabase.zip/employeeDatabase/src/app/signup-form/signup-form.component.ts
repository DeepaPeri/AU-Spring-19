import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { User } from './signup.interface';

@Component({
	selector: 'app-signup-form',
	templateUrl: './signup-form.component.html',
	styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent implements OnInit {
	user: FormGroup;
	constructor(private fb: FormBuilder) { }

	ngOnInit() {
		this.user = this.fb.group({
			name: ['', Validators.required],
			account: this.fb.group({
				email: ['', Validators.required],
				confirm: ['', Validators.required]
			})
		});
	}

	onSubmit({ value, valid }: { value: User, valid: boolean }) {
		console.log(value, valid);
	}
}