import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { EmployeeComponent } from './employee/employee.component';
import {DateComponent} from './date/date.component';
import {EmployeeListComponent} from 'src/app/employee/employee-list/employee-list.component';
import {SignupFormComponent} from 'src/app/signup-form/signup-form.component';
import {SingUpTemplateComponent} from 'src/app/sing-up-template/sing-up-template.component';

const routes: Routes = [
  { path: 'date', component: DateComponent },
  { path: 'employeelist/:id', component: EmployeeListComponent },
  { path: 'employeelist', component: EmployeeListComponent },
  { path: 'signup', component: SignupFormComponent},
  { path: 'signuptemplate', component: SingUpTemplateComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
