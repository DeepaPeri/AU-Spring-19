import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DateComponent } from './date/date.component';
import { DirectiveModuleDirective } from './directive-module.directive';
import { EmployeeListComponent } from './employee/employee-list/employee-list.component';

import {HttpClientModule} from '@angular/common/http';
import { TestServiceService } from './test-service.service';
import { ReactiveFormsModule } from '@angular/forms';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { SingUpTemplateComponent } from './sing-up-template/sing-up-template.component';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DateComponent,
    DirectiveModuleDirective,
    EmployeeListComponent,
    SignupFormComponent,
    SingUpTemplateComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
   
  ],
  providers: [TestServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
